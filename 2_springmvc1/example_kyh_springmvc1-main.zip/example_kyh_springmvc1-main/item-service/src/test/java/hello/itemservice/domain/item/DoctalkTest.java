package hello.itemservice.domain.item;

import hello.itemservice.domain.autorecommendmessage.ComplexHealthInformationMessageDto;
import hello.itemservice.domain.autorecommendmessage.enums.HealthInformationGender;
import hello.itemservice.domain.rfm.DateRange;
import hello.itemservice.domain.rfm.dto.RfmBatchDate;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
class DoctalkTest {



    @Test
    public void ldInRangeInclusiveTest() {

        LocalDateTime updateAt = LocalDateTime.of(2022, 3, 10, 10, 54, 59);
        LocalDateTime updatedDateTime = LocalDateTime.of(2022, 3, 10, 10, 54, 58, 30000);
        LocalDateTime nowDateTime5MinutesMinus = updateAt.minusMinutes(5);
        boolean b = ldInRangeInclusive(updatedDateTime, nowDateTime5MinutesMinus, updateAt);

        System.out.println("b = " + b);
    }

    private static boolean ldInRangeInclusive(LocalDateTime check, LocalDateTime start, LocalDateTime end) {
        return !check.isBefore(start) && !check.isAfter(end);
    }

    @Test
    public void insertEmrDiagnoses() {

        List<InsertEmrDiagnosisHistoryDto> emrDiagnosisHistoryList = InsertEmrDiagnosisHistoryDto.init2();

        int totalSize = emrDiagnosisHistoryList.size();

        int startIndex = 0;
        int batchSize = 5000;
        int endIndex = 5000;
        int distribution = (int) Math.ceil(totalSize / endIndex);

        if (endIndex > totalSize) {

        } else {
            for (int i = 0; i < distribution + 1; i++) {
                List<InsertEmrDiagnosisHistoryDto> insertEmrDiagnosisHistoryDtoList = emrDiagnosisHistoryList.subList(startIndex, endIndex);
                log.info("insertEmrDiagnosisHistoryDtoList={}", insertEmrDiagnosisHistoryDtoList);

                startIndex = endIndex;
                endIndex = Math.min(totalSize, endIndex + batchSize);
            }
        }
    }

    @Test
    public void RFM_배치_START_END_DATE_계산_테스트() {

        //        EmrDiagnosisHistoryMaxVisitedAtAndMinVisitedAtDto emrDiagnosisHistoryMaxVisitedAtAndMinVisitedAtDto = repositories.emrDiagnosisRepository
        //                .selectEmrDiagnosisHistoryMaxVisitedAtAndMinVisitedAt("39932222");
        //
        //        LocalDate minVisitedAt = emrDiagnosisHistoryMaxVisitedAtAndMinVisitedAtDto.getMinVisitedAt();
        //        LocalDate maxVisitedAt = emrDiagnosisHistoryMaxVisitedAtAndMinVisitedAtDto.getMaxVisitedAt();

        LocalDate minVisitedAt = LocalDate.of(2022, 5, 16);
        LocalDate maxVisitedAt = LocalDate.of(2022, 5, 25);

        RfmBatchDate rfmBatchDate = RfmBatchDate.calculateRfmBatchDate(
                LocalDate.now(),
                minVisitedAt,
                maxVisitedAt
        );

        minVisitedAt = rfmBatchDate.getStartDate();
        maxVisitedAt = rfmBatchDate.getEndDate();
        LocalDate middleDate = rfmBatchDate.getMiddleDate();
        LocalDate batchStartDate = rfmBatchDate.getBatchStartDate();

        List<LocalDate> localDates = new DateRange(middleDate, maxVisitedAt).toList();
        log.info("localDates={}", localDates);
    }

    @Test
    public void textSeach() {
        String txt1 = "가나다라" ;
        String txt2 = "해당 내용은 테스트 입니다" ;
        String txt3 = "가격은 29,000원 입니다" ;



        // contains를 이용한 방법(true, false 반환)
        if(txt1.contains("나다"))
            System.out.println("문자열 있음!");
        else
            System.out.println("문자열 없음!");


        // indexOf를 이용한 방법
        if(txt2.indexOf("테스트") > -1)
            System.out.println("문자열 있음!");
        else
            System.out.println("문자열 없음!");


        // matches를 이용한 방법
        if(txt2.matches(".*테스트.*"))
            System.out.println("문자열 있음!");
        else
            System.out.println("문자열 없음!");


        // matches를 이용하여 정규 표현식으로 문자열에 숫자가 있는지 확인
        if(txt3.matches(".*[0-9].*"))
            System.out.println("숫자 있음!");
        else
            System.out.println("숫자 없음!");


        List<String> list = new ArrayList<>();
        list.add("Apple");
        list.add("Kiwi");
        list.add("Orange");

        String fruit = "Orange";

        if (list.contains(fruit)) {
            System.out.println(fruit + " is in the List");
        }
    }

    @Test
    public void equalsTest() {

//        ComplexHealthInformationMessageDto.createComplexHealthInformationMessageDto(
//                "안녕", Month.APRIL, HealthInformationGender.
//        );

    }

    @Test
    public void eee() {
        List<String> diseasePredictMessages = null;
        String[] sArrays = diseasePredictMessages.toArray(new String[0]);
        System.out.println("sArrays = " + sArrays);
    }
}